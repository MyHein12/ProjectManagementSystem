- cần change pwd khi lần đầu đăng nhập.
- pwd được gửi lần đầu qua mail + khi reset pwd.

default account
HR:
	HRexample@gmai.com
	HRexample123
CEO:
	CEOexample@gmail.com
	CEOexample123