def extended_euclid(a,b):
    x0,y0, x1,y1 = 1,0, 0,1
    while b!=0:
        d=b
        q = a // b
        r = a % b
        a = b
        b = r
        x2 = x0 - q*x1
        y2 = y0 - q*y1
        x0,y0 = x1,y1
        x1,y1 = x2,y2
    return d,x0,y0

def inverse_modulo_n(a,n):
    gcd,x,y = extended_euclid(a,n)
    if gcd==1:
        return x%n
    return None

print(extended_euclid(19,12))
print(inverse_modulo_n(19,12))

print(extended_euclid(10,15))
print(inverse_modulo_n(10,15))