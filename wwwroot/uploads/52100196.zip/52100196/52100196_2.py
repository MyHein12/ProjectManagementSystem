# Hàm tính số d
def find_d(e, phi_n):
    d = 0
    while True:
        if (e * d) % phi_n == 1:
            return d
        d += 1
 
# Hàm mã hóa thông điệp
def encrypt(m, e, n):
    c = (m**e)%n
    return c
 
# Hàm giải mã thông điệp
def decrypt(c, d, n):
    m = (c**d)%n
    return m
 
# Chọn hai số nguyên tố lớn
p = 19
q = 17
 
# Tính n và phi(n)
n = p * q
phi_n = (p - 1) * (q - 1)
 
# Chọn số nguyên tố e
e = 5

# Chọn thông điệp
message = "hello Han"

# Tính số d
d = find_d(e, phi_n)
 
# Khóa công khai và khóa bí mật
public_key = (e, n)
private_key = (d, n)
 
# Mã hóa và giải mã thông điệp
message_ascii = [ord(c) for c in message] # chuyển đổi các ký tự thành mã ASCII
encrypted_message = [encrypt(m, e, n) for m in message_ascii] # mã hóa thông điệp
decrypted_message_ascii = [decrypt(c, d, n) for c in encrypted_message] # giải mã thông điệp
decrypted_message = ''.join([chr(c) for c in decrypted_message_ascii]) # chuyển đổi mã ASCII thành ký tự
 
# In kết quả
print("Message:", message)
print("Message ascii: ", message_ascii)
print("Encrypted message:", encrypted_message)
print("Decrypted message ascii: ", decrypted_message_ascii)
print("Decrypted message:", decrypted_message)


from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes

# Tạo một cặp khóa mới
private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
public_key = private_key.public_key()

# Chuyển đổi thông điệp thành dạng bytes
message = 'hello Han'
message_bytes = message.encode('utf-8')

# Mã hóa thông điệp
ciphertext = public_key.encrypt(
    message_bytes, 
    padding.OAEP(
        mgf=padding.MGF1(algorithm=hashes.SHA256()),
        algorithm=hashes.SHA256(),
        label=None
    )
)

# Giải mã thông điệp
plaintext = private_key.decrypt(
    ciphertext,
    padding.OAEP(
        mgf=padding.MGF1(algorithm=hashes.SHA256()),
        algorithm=hashes.SHA256(),
        label=None
    )
)

# Chuyển đổi kết quả giải mã thành chuỗi ký tự
plaintext_str = plaintext.decode('utf-8')

# In kết quả
print('Mã hóa:', ciphertext)
print('Giải mã:', plaintext_str)